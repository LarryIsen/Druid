﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Druid : MonoBehaviour {

	public int health;
	public AudioSource audioData;
	public SpriteRenderer hitFlash;
	public Rigidbody2D rigidBody;
	public float jumpDir;
	public bool isJump;
	public int isRed;
	public bool isDead;
	public float hangtime;
	public Sprite[] sprites;
	int deathTimer = 0;

	private Animator animator;

	static public Druid ronian;
	public int stageNumber = 1;

	//void Awake(){
	//	ronian = this;
	//}

	// Use this for initialization
	void Start () {
		if (stageNumber == 1) {
			health = 1000;
		} else if (stageNumber == 2) {
			health = 750;
		} else if (stageNumber == 3) {
			health = 2000;
		}
		ronian = this;
		jumpDir = 2f;	
		isJump = false;
		isDead = false;
		hitFlash = GetComponent<SpriteRenderer> ();
		audioData = GetComponent<AudioSource>();

		//Since the sprite image faces left but the actual object is facing right, I need to rotate
		//the object and then flip the sprite image so both are facing left:
		transform.Rotate (0f, 180f, 0f, Space.Self);
		hitFlash.flipX = true; //The variable name doesn't really fit, but it still does what I want it to.

	}

	// Update is called once per frame
	void Update () {

		var number = Random.Range (1, 21);


		if (isDead == false) {
			if ((number == 1) && (isJump == false) && (Shooting.isShooting > 1)) {
				isJump = true;
				hangtime = 0.01f;
			}


			if (isJump) {
				jumpDir = -9.65f * hangtime + 4.825f;
				rigidBody.velocity = transform.up * jumpDir;
				hangtime += Time.timeScale * 0.015f;
				if (hangtime >= 1.0f) {
					isJump = false;
				}

				if (DruidShooting.isShooting == 2) {
					if (sprites != null) {
						this.GetComponent<SpriteRenderer> ().sprite = sprites [2];
					}
				} else if (isJump) {
					if (sprites != null) {
						this.GetComponent<SpriteRenderer> ().sprite = sprites [1];
					}
				} else {
					if (sprites != null) {
						this.GetComponent<SpriteRenderer> ().sprite = sprites [0];
					}
				}

			}

		} else { //if isDead== true
			deathTimer++;
			if (deathTimer >= 10) {
				Time.timeScale = 0;
			}
			if (deathTimer >= 100) {
				Time.timeScale = 0.5f; //1;
				SceneManager.LoadScene ("Victory!");
			}
			if (sprites != null) {
				this.GetComponent<SpriteRenderer> ().sprite = sprites [0];
			}
			rigidBody.velocity = transform.up * 0;
			rigidBody.velocity = transform.right * -5;
		}

		if (isRed > 0) {
			isRed = isRed + 1;
			if (isRed > 5) {
				hitFlash.color = new Color (1f, 1f, 1f, 1f);
				isRed = 0;
			}
		}
	}

	public void TakeDamage (int damage)
	{
		hitFlash.color = new Color(0.5f, 0.5f, 0.5f, 1f);
		isRed = 1;
		health -= damage;
		audioData.Play (0);
		if ((health <= 0) && (!isDead)) {
			isDead = true;
			Die ();
		}
	}

	void Die ()
	{
		if (sprites != null) {
			this.GetComponent<SpriteRenderer> ().sprite = sprites [0];
		}
		transform.Rotate (new Vector3 (0, 0, 90));
	}

	/*--------------Experimental stuff after this line-----------------*/



}
