﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;

public class DragonHealthControl : MonoBehaviour {

		Slider sliderValue;
		RectTransform sliderScale;

		// Use this for initialization
		void Start () {
			sliderValue = GetComponent<Slider> ();
			sliderScale = GetComponent<RectTransform> ();
		}

		// Update is called once per frame
		void Update () {
			if (Dragon.dragon.health >= 0) {
			sliderValue.value = Dragon.dragon.health;
			} else {
				sliderValue.value = 0;
				//Vector3 scale = sliderScale.transform.localScale;
				Vector3 scale = sliderScale.transform.lossyScale;
				scale.x = 0;
				scale.y = 0;
				scale.z = 0;
				sliderScale.transform.localScale = scale;
			}
		}
	}
