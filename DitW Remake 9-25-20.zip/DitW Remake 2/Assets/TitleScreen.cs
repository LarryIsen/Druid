﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class TitleScreen : MonoBehaviour {

	public string gameSceneName="Scene-1";
	public int counter;
	static public bool returned;


	// Use this for initialization
	void Start () {
		returned = false;
		counter = 0;
	} //Start


	
	// Update is called once per frame
	void Update () {


		//if (Input.GetKeyUp (KeyCode.Return)) {
		//	SceneManager.LoadScene(gameSceneName);
		//}




		if (Input.GetKeyUp (KeyCode.Return)) {
			returned = true;
		}

		if (returned) {
			counter++;
		}

		if (counter > 100) {
			//returned = false;
			//DruidShooting.isShooting = 0;
			//Shooting.isShooting = 0;
			SceneManager.LoadScene(gameSceneName);
		}

	}// Update
}
