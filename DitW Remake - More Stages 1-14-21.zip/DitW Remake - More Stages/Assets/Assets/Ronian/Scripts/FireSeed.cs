﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireSeed : MonoBehaviour {

	public float speed;
	public Rigidbody2D rb;
	public int damage;

	public SpriteRenderer shotSprite;
	public Sprite[] sprites;

	// order of shots: null, arrow, deadly shot, magic missile, fireball, lightning bolt, fire seed

	public float[] shotSpeed={0f, 15f, 20f, 20f, 15f, 30f, 25f};
	public int[] lowDamage={0, 1, 6, 8, 20, 10, 2};
	public int[] highDamage={0, 7, 57, 21, 121, 61, 17};

	static public float[] colorRed   = { 0f, 75f, 150f, 150f, 255f, 0f, 255f };
	static public float[] colorGreen = { 0f, 75f, 150f, 150f, 0f, 0f, 0f };
	static public float[] colorBlue  = { 0f, 75f, 150f, 255f, 0f, 0f, 0f };

	static int[] shotSpriteType = { 0, 0, 0, 0, 1, 2, 3 };

	float shotRed;
	float shotBlue;
	float shotGreen;

	// Use this for initialization
	void Start () {

		//speed = 25f; //To be replaced by array variables
		speed = shotSpeed[DruidShooting.shotType];
		rb.velocity = transform.right * speed;

		shotSprite = GetComponent<SpriteRenderer> ();

		if (sprites != null) {
			this.GetComponent<SpriteRenderer> ().sprite = sprites [shotSpriteType[DruidShooting.shotType]];
		}

		shotRed = colorRed [DruidShooting.shotType]/255;
		shotGreen = colorGreen [DruidShooting.shotType]/255;
		shotBlue = colorBlue [DruidShooting.shotType]/255;

		Color newColor = new Color(shotRed, shotGreen, shotBlue, 1f);
		shotSprite.color=(newColor);

	}
	
	// Update is called once per frame
	void Update () {
		//In here will go the routines that make the Wizard's Fireball and lightning bolt flash
		//and make the Magic Missile follow the Dragon's Y position.

		/* Flashing */
		if (DruidShooting.shotType == 5) {
			shotRed = Random.Range (0f, 1f);
			shotBlue = Random.Range (0f, 1f);
		}

		if ((DruidShooting.shotType == 4) || (DruidShooting.shotType == 5)) {
			shotGreen = Random.Range (0f, 1f);
			Color newColor = new Color(shotRed, shotGreen, shotBlue, 1f);
			shotSprite.color=(newColor);
		}

		/* Tracking */

		if (DruidShooting.shotType == 3) {
			/*float jumpHeight = Dragon.dragon.hitFlash.transform.position.y;
			Transform missile = GetComponent<Transform> ();
			float missileHeight = missile.transform.position.y;
			missileHeight = jumpHeight;
			//missile.transform.position.y = jumpHeight; doesn't work, can't assign that directly.
			*/
			float dragonY = Dragon.dragon.hitFlash.transform.position.y;
			Transform missile = GetComponent<Transform> ();
			float missileY = missile.transform.position.y;

			if (dragonY != missileY) {
				float upOrDown = 20*(dragonY - missileY); // / Mathf.Abs (dragonY - missileY);
				rb.velocity = new Vector3 (-speed, upOrDown, 0);
					//transform.up * upOrDown;
			}

		}

	}

	void OnTriggerEnter2D (Collider2D hitInfo)
	{
		int low = lowDamage [DruidShooting.shotType];
		int high = highDamage [DruidShooting.shotType];

		Dragon dragon = hitInfo.GetComponent<Dragon> ();
		if (dragon != null) {
			//Color newColor = new Color(0.3f, 0.3f, 0.3f, 1f);
			//CameraScript.HitFlash (newColor);
			//damage = 10;
			//int damage = Random.Range(2,17); //To be replaced by array variables
			int damage = Random.Range(low,high);
			dragon.TakeDamage (damage);
		}
		Destroy(gameObject);
		DruidShooting.isShooting = 0;
		DruidShooting.shotType = 0;
	}
}