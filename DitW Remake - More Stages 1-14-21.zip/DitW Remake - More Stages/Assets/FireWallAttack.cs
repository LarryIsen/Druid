﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireWallAttack : MonoBehaviour {


	public bool hit;
	public float timer = 0.0f;
	public float delayBetweenFrames = 0.05f;
	public int amtAnimationFrames = 7;
	public int currentFrame = 0;
	public Sprite[] wallimation;
	SpriteRenderer spriteRenderer;


	// Use this for initialization
	void Start () {

		hit = false;

		spriteRenderer = GetComponent<SpriteRenderer>();
		spriteRenderer.sprite = wallimation[0];

	} //Start()
	
	// Update is called once per frame
	void Update () {


		/* this.GetComponent<SpriteRenderer> ().sprite = wallimation [index++];
		if (index >= 6) { 
			Destroy (this.gameObject);
		} */

		if(timer <= delayBetweenFrames)
		{
			timer += Time.deltaTime;
		}
		else
		{
			timer = 0.0f;
			currentFrame++;

			if (currentFrame == amtAnimationFrames - 1) {
				Destroy (gameObject);
				DruidShooting.isShooting = 0;
			}

			spriteRenderer.sprite = wallimation[currentFrame];

		}

		//Destroy (this.gameObject);
		//print ("destroy?");

	} //Update()


	void OnTriggerEnter2D (Collider2D hitInfo)
	{

		Dragon dragon = hitInfo.GetComponent<Dragon> ();

		if ((dragon != null) && (!hit)) {
			//Color newColor = new Color(0.3f, 0.3f, 0.3f, 1f);
			//CameraScript.HitFlash (newColor);
			//int damage = 20;
			int damage = Random.Range(27,40);
			dragon.TakeDamage (damage);
			hit = true; //it should hit only once, no matter how long the fire sprite lasts
		}
	}

}