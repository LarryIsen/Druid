﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.Threading;

public class StageIntro : MonoBehaviour {

	int SN = TitleScreen.stageNumber; //Just to make it easier to type
	//string[] nameArray = new string[3] {"A Warrior On The Plains", "A Wizard In The Desert", "Ronian, A Druid In The Woods"};
	string[] nameArray = new string[3] {"A WARRIOR ON THE PLAINS", "A WIZARD IN THE DESERT", "RONIAN, A DRUID IN THE WOODS"};
	public Text stageName; //ha, ha, it's a pun

	public string gameSceneName="Scene-1";

	int timer = 0;



	// Use this for initialization
	void Start () {
		stageName = this.GetComponent<Text> ();
		if (SN < 1) {
			SN = 1;
		} else if (SN > 3) {
			SN = 3;
		} // Shouldn't be an issue, but just in case
		stageName.text = "\r\n STAGE " + SN.ToString () + "\r\n " + nameArray [SN - 1];
	}
	
	// Update is called once per frame
	void Update () {
		timer++;
		if (timer > 200) {
			SceneManager.LoadScene (gameSceneName);
		}
	}
}