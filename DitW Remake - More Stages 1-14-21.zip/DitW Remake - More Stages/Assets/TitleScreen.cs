﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class TitleScreen : MonoBehaviour {

	public string gameSceneName="Stage Screen";
	public int counter;
	static public bool returned;

	static public int stageNumber;


	// Use this for initialization
	void Start () {
		returned = false;
		counter = 0;
	} //Start


	
	// Update is called once per frame
	void Update () {

		if (Input.GetKeyUp (KeyCode.Return)) {
			returned = true;
		}

		if (returned) {
			counter++;
		}

		if (counter > 100) {
			stageNumber = 1;
			//SceneManager.LoadScene(gameSceneName);
			SceneManager.LoadScene ("Stage Screen");
		}

	}// Update
}
