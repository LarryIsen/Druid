﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraScript : MonoBehaviour {

	public Color color1 = Color.red;
	public Color color2 = Color.blue;
	public Color[] colors;
	public float duration = 3.0F;
	public int flashing;

	public bool flash;

	public Camera cam;

	void Start()
	{
		cam = GetComponent<Camera>();
		cam.clearFlags = CameraClearFlags.SolidColor;
	} // Start()



	void Update()
	{
		//float t = Mathf.PingPong(Time.time, duration) / duration;
		//cam.backgroundColor = Color.Lerp(color1, color2, t);

		/*colors [0] = Color.black;
		colors [1] = Color.white;

		if ((Input.GetKey (KeyCode.I)) && (!flash)) {
			flash = true;
			flashing = 0;
		} //If "I" then start screen flash

		if (flash){
			 {
				flashing += 1;
				cam.backgroundColor = colors [(flashing & 8)/8];

				if (flashing >= 100) {
					flash = false;
					cam.backgroundColor = Color.black;
				}
			}
		} //screen flash, part 2 
		*/

	} // Update()

	//public void HitFlash(Color flashColor) {
	//	cam.backgroundColor = flashColor;
	//	yield return new WaitForSecondsRealtime (0.1f);
	//	cam.backgroundColor = Color.black;
	//}

}
