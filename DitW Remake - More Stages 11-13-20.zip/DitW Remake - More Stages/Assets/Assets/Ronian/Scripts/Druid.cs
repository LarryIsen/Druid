﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Druid : MonoBehaviour {

	public int health;
	public AudioSource audioData;
	public SpriteRenderer hitFlash;
	public Rigidbody2D rigidBody;
	public float jumpDir;
	public bool isJump;
	public int isRed;
	public bool isDead;
	public float hangtime;
	public Sprite[] sprites;
	int deathTimer = 0;

	private Animator animator;

	static public Druid ronian;


	//void Awake(){
	//	ronian = this;
	//}

	// Use this for initialization
	void Start () {


		/* sprite calculations:
		 * Standing = (SN-1)*4
		 * Jumping = (SN-1)*4 + 1
		 * Windup = (SN-1)*4 + 2
		 * Shooting = (SN-1)*4 + 3
		*/

		if (TitleScreen.stageNumber < 1) {
			TitleScreen.stageNumber = 1;
		}

		int SN = TitleScreen.stageNumber;
		int spriteStandValue = (SN - 1) * 4;
		print (spriteStandValue);
		int spriteJumpValue = (SN - 1) * 4 + 1;
		print (spriteJumpValue);
		int spriteWindupValue = (SN - 1) * 4 + 2;
		print (spriteWindupValue);
		int spriteShootValue = (SN - 1) * 4 + 3;
		print (spriteShootValue);

		if (sprites != null) {
			this.GetComponent<SpriteRenderer> ().sprite = sprites [spriteStandValue];
		}

		if (TitleScreen.stageNumber == 1) {
			health = 1000;
		} else if (TitleScreen.stageNumber == 2) {
			health = 750;
		} else if (TitleScreen.stageNumber == 3) {
			health = 2000;
		}
		ronian = this;
		jumpDir = 2f;	
		isJump = false;
		isDead = false;
		hitFlash = GetComponent<SpriteRenderer> ();
		audioData = GetComponent<AudioSource>();

		//Since the sprite image faces left but the actual object is facing right, I need to rotate
		//the object and then flip the sprite image so both are facing left:
		transform.Rotate (0f, 180f, 0f, Space.Self);
		hitFlash.flipX = true; //The variable name doesn't really fit, but it still does what I want it to.


	}

	// Update is called once per frame
	void Update () {

		var number = Random.Range (1, 21);

		/* sprite calculations:
		 * Standing = (SN-1)*4
		 * Jumping = (SN-1)*4 + 1
		 * Windup = (SN-1)*4 + 2
		 * Shooting = (SN-1)*4 + 3
		*/

		int SN = TitleScreen.stageNumber;
		int spriteStandValue = (SN - 1) * 4;
		int spriteJumpValue = (SN - 1) * 4 + 1;
		int spriteWindupValue = (SN - 1) * 4 + 2;
		int spriteShootValue = (SN - 1) * 4 + 3;

		if (isDead == false) {
			if ((number == 1) && (isJump == false) && (Shooting.isShooting > 1)) {
				isJump = true;
				hangtime = 0.01f;
			}

			if (DruidShooting.isShooting == 2) {
				if (sprites != null) {
					this.GetComponent<SpriteRenderer> ().sprite = sprites [spriteWindupValue];
				}
			} else if (isJump) {
				if (sprites != null) {
					this.GetComponent<SpriteRenderer> ().sprite = sprites [spriteJumpValue];
				}
			} else {
				if (sprites != null) {
					this.GetComponent<SpriteRenderer> ().sprite = sprites [spriteStandValue];
				}
			}

			if (isJump) {
				jumpDir = -9.65f * hangtime + 4.825f;
				rigidBody.velocity = transform.up * jumpDir;
				hangtime += Time.timeScale * 0.015f;
				if (hangtime >= 1.0f) {
					isJump = false;
				}

				/*if (DruidShooting.isShooting == 2) {
					if (sprites != null) {
						this.GetComponent<SpriteRenderer> ().sprite = sprites [spriteWindupValue];
					}
				} else if (isJump) {
					if (sprites != null) {
						this.GetComponent<SpriteRenderer> ().sprite = sprites [spriteJumpValue];
					}
				} else {
					if (sprites != null) {
						this.GetComponent<SpriteRenderer> ().sprite = sprites [spriteStandValue];
					}
				}*/

			} //if (isJump)

		} else { //if isDead== true
			deathTimer++;
			if (deathTimer >= 10) {
				Time.timeScale = 0;
			}
			if (deathTimer >= 100) {
				Time.timeScale = 0.5f; //1;
				if (TitleScreen.stageNumber >= 3) {
					SceneManager.LoadScene ("Victory!");
				} else {
					TitleScreen.stageNumber++; 
					SceneManager.LoadScene ("Scene-1");
				}
			}
			if (sprites != null) {
				this.GetComponent<SpriteRenderer> ().sprite = sprites [spriteStandValue];
			}
			rigidBody.velocity = transform.up * 0;
			rigidBody.velocity = transform.right * -5;
		}

		if (isRed > 0) {
			isRed = isRed + 1;
			if (isRed > 5) {
				hitFlash.color = new Color (1f, 1f, 1f, 1f);
				isRed = 0;
			}
		}
	}

	public void TakeDamage (int damage)
	{
		hitFlash.color = new Color(0.5f, 0.5f, 0.5f, 1f);
		isRed = 1;
		health -= damage;
		audioData.Play (0);
		if ((health <= 0) && (!isDead)) {
			isDead = true;
			Die ();
		}
	}

	void Die ()
	{
		/* sprite calculations:
		 * Standing = (SN-1)*4
		 * Jumping = (SN-1)*4 + 1
		 * Windup = (SN-1)*4 + 2
		 * Shooting = (SN-1)*4 + 3
		*/

		int SN = TitleScreen.stageNumber;
		int spriteStandValue = (SN - 1) * 4;
		int spriteJumpValue = (SN - 1) * 4 + 1;
		int spriteWindupValue = (SN - 1) * 4 + 2;
		int spriteShootValue = (SN - 1) * 4 + 3;

		if (sprites != null) {
			this.GetComponent<SpriteRenderer> ().sprite = sprites [spriteStandValue];
		}
		transform.Rotate (new Vector3 (0, 0, 90));
	}

	/*--------------Experimental stuff after this line-----------------*/



}
