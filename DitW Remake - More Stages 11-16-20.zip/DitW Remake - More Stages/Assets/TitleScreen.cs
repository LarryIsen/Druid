﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class TitleScreen : MonoBehaviour {

	public string gameSceneName="Scene-1";
	public int counter;
	static public bool returned;

	static public int stageNumber;


	// Use this for initialization
	void Start () {
		returned = false;
		counter = 0;
	} //Start


	
	// Update is called once per frame
	void Update () {

		if (Input.GetKeyUp (KeyCode.Return)) {
			returned = true;
		}

		if (returned) {
			counter++;
		}

		if (counter > 100) {
			SceneManager.LoadScene(gameSceneName);
			stageNumber = 1;
		}

	}// Update
}
