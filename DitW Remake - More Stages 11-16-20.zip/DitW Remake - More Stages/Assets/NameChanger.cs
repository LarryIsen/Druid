﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class NameChanger : MonoBehaviour {

	int SN = TitleScreen.stageNumber; //Just to make it easier to type
	string[] nameArray = new string[3] {"Warrior", "Wizard", "Ronian"};

	public Text nameChange;



	// Use this for initialization
	void Start () {

		nameChange = this.GetComponent<Text> ();

		if ((SN > 0) && (SN < 4)) {
			print (nameArray [SN - 1]);
			nameChange.text = nameArray [SN - 1];
		}

	}
	
	// Update is called once per frame
	void Update () {
	
	}
		
		
}
