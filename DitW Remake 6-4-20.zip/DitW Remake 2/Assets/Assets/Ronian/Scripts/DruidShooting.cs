﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DruidShooting : MonoBehaviour {

	public Transform fireSeed;
	public GameObject seedDot;

	public int counter = 0;
	static public bool isShooting = false;
	public Sprite [] sprites;
	public SpriteRenderer colorPicker;




	// Update is called once per frame
	void Update () {

		if (Time.timeScale != 0) {
			var shooting = Random.Range (1, 1001);

			if ((shooting<10) && (!isShooting)) {
				FireSeed();
			} //If shooting<10
		} //if (Time.timeScale != 0)



		if (Input.GetKeyDown (KeyCode.U)) {
			FireSeed ();
		} //if (Input.GetKeyDown (KeyCode.U))


	}

	void FireSeed () {
		Instantiate (seedDot, fireSeed.position, fireSeed.rotation);
		isShooting = true;
	}

	/*void LightningShoot () {
		//colorPicker.color = new Color (1f, 1f, 1f, 1f);
		Instantiate (zappyZap, lightningPoint.position, lightningPoint.rotation);
		isShooting = true;
		if (sprites != null) {
			this.GetComponent<SpriteRenderer> ().sprite = sprites [0];
		}
	}*/
}
