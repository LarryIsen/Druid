﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class lightningPoint : MonoBehaviour {

	public float speed;
	public Rigidbody2D rb;
	public int damage;


	//Use this for initialization
	void Start () {
		speed = 10f;
		rb.velocity = transform.right * speed;
	}

	void Update () {
		transform.Rotate (new Vector3 (0, 0, -speed));
	}

	void OnTriggerEnter2D (Collider2D hitInfo)
	{
		Debug.Log(hitInfo.name);
		Druid druid = hitInfo.GetComponent<Druid> ();
		if (druid != null) {
			druid.TakeDamage (damage);
		}

		Destroy(gameObject);

	}

}