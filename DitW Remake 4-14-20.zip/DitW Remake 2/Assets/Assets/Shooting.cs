﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// NOT THIS ONE... WHY CAN'T I DELETE THIS?
/// I keep deleting it and it keeps coming back!  Whyyyyyyyyyyy?
/// </summary>

public class GLOOPING : MonoBehaviour {

	public Transform firePoint;
	public GameObject spinnyStar;
	
	// Update is called once per frame
	void Update () {
		if (Input.GetKeyDown("g")) {
			Shoot ();
		}
	}

	void Shoot () {
	
		Instantiate (spinnyStar, firePoint.position, firePoint.rotation);
	
	}
}
