﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Druid : MonoBehaviour {

	public int health = 2000;
	public AudioSource audioData;
	public Rigidbody2D ronian;
	public float jumpDir;
	public bool isJump;
	public bool isDead;
	public float time;

	// Use this for initialization
	void Start () {
		jumpDir = 2f;	
		isJump = false;
		isDead = false;
	}

	// Update is called once per frame
	void Update () {
		var number = Random.Range (1, 26);
		if (isDead == false) {
			if ((number == 1) && (isJump == false)) {
				isJump = true;
				time = 0.01f;
			}


			if (isJump) {
				jumpDir = -9.65f * time + 4.825f;
				ronian.velocity = transform.up * jumpDir;
				time += 0.01f;
				if (time >= 2f) {
					isJump = false;
				}
			}
		

		} else {
			ronian.velocity = transform.up * 0;
			ronian.velocity = transform.right * 5;
		}
	}

	public void TakeDamage (int damage)
	{
		health -= damage;
		Debug.Log(damage);
		Debug.Log(health);
		audioData = GetComponent<AudioSource>();
		audioData.Play (0);
		if (health <= 0) {
			Die ();
		}
	}

	void Die ()
	{
		isDead = true;
		Debug.Log ("DEAD NOW!  EXPLOSION!");
		transform.Rotate (new Vector3 (0, 0, -90));
	}




}
