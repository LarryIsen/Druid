﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class Victory : MonoBehaviour {

	public string gameSceneName="Scene-1";

	public Text myText;

	// Use this for initialization
	void Start () {
		myText.text = "YOU WIN!";
	} //Start

	// Update is called once per frame
	void Update () {

		if (Input.GetKey (KeyCode.Return)) {
			SceneManager.LoadScene(gameSceneName);
		}


	}// Update
}
