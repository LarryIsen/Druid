﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class callLightning : MonoBehaviour {

	public bool hitDragonOrFloor = false;
	public GameObject Lightning;
	public Transform thisLightning;
	static public bool hit;

	int t=0; // timer for lightning disappearance

	// Use this for initialization
	void Start () {
		hit = false;
		if (CallCallLightning.bolts < 12) {
			Vector3 loc = thisLightning.position;
			loc.y = loc.y - 0.5f;
			loc.x = loc.x - 0.5f;
			Instantiate (Lightning, loc, Quaternion.identity);
			CallCallLightning.bolts++;
		}
	}
	
	// Update is called once per frame
	void Update () {
		t++;
		if (t > 5) {
			Destroy (gameObject);
		}
	}

	void OnTriggerEnter2D (Collider2D hitInfo)
	{

		Dragon dragon = hitInfo.GetComponent<Dragon> ();

		if ((dragon != null) && (!hit)) {
			//Color newColor = new Color(0.3f, 0.3f, 0.3f, 1f);
			//CameraScript.HitFlash (newColor);
			int damage = 30;
			dragon.TakeDamage (damage);
			hit = true; //it should hit only once, no matter how long the bolt sprite lasts
		}
	}
}
