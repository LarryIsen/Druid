﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;


public class TitleScreen : MonoBehaviour {

	public string gameSceneName="Scene-1";

	public Text myText;

	// Use this for initialization
	void Start () {
		
	} //Start
	
	// Update is called once per frame
	void Update () {

		myText.text = "DRUID IN THE WOODS: REMAKE";


		if (Input.GetKey (KeyCode.Return)) {
			SceneManager.LoadScene(gameSceneName);
		}


	}// Update
}
