using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class firePoint : MonoBehaviour {

	public float speed;
	public Rigidbody2D rb;
	public int damage;


	//Use this for initialization
	void Start () {
		speed = 15f;
		rb.velocity = transform.right * speed;
	}

	void Update () {
		transform.Rotate (new Vector3 (0, 0, -speed * Time.timeScale));
	}

	void OnTriggerEnter2D (Collider2D hitInfo)
	{
		Druid druid = hitInfo.GetComponent<Druid> ();
		if (druid != null) {
			//Color newColor = new Color(0.3f, 0.3f, 0.3f, 1f);
			//CameraScript.HitFlash (newColor);
			damage = 10;
			druid.TakeDamage (damage);
		}

		Destroy(gameObject);
		Shooting.isShooting -= 1;
	}

}