﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DruidShooting : MonoBehaviour {

	public Transform fireSeed;
	public GameObject seedDot;

	public int counter = 0;
	static public bool isShooting = false;
	public Sprite [] sprites;
	public SpriteRenderer colorPicker;




	// Update is called once per frame
	void Update () {

		if (Time.timeScale != 0) {
			var shooting = Random.Range (1, 1001);

			if ((shooting<10) && (!isShooting)) {
				FireSeed();
			} //If shooting<10
		} //if (Time.timeScale != 0)

		/*
		if (Input.GetKeyDown (KeyCode.U)) {
			FireSeed ();
		} //if (Input.GetKeyDown (KeyCode.U))
		*/
			
	}

	void FireSeed () {

		Vector3 loc = fireSeed.position;
		loc.x = loc.x - 0.5f; //temp - 1;

		Instantiate (seedDot, loc, fireSeed.rotation);
		isShooting = true;
	}
}
