﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Druid : MonoBehaviour {

	public int health = 2000;
	public AudioSource audioData;
	public SpriteRenderer hitFlash;
	public Rigidbody2D rigidBody;
	public float jumpDir;
	public bool isJump;
	public int isRed;
	public bool isDead;
	public float time;

	private Animator animator;

	static public Druid ronian;

	//void Awake(){
	//	ronian = this;
	//}

	// Use this for initialization
	void Start () {
		ronian = this;
		jumpDir = 2f;	
		isJump = false;
		isDead = false;
		hitFlash = GetComponent<SpriteRenderer> ();
		audioData = GetComponent<AudioSource>();
	}

	// Update is called once per frame
	void Update () {

		var number = Random.Range (1, 26);


		if (isDead == false) {
			if ((number == 1) && (isJump == false) && (Shooting.isShooting)) {
				isJump = true;
				time = 0.01f;
			}


			if (isJump) {
				jumpDir = -9.65f * time + 4.825f;
				rigidBody.velocity = transform.up * jumpDir;
				time += 0.015f;
				if (time >= 2f) {
					isJump = false;
				}
			}
		

		} else {
			rigidBody.velocity = transform.up * 0;
			rigidBody.velocity = transform.right * 5;
		}
		if (isRed > 0) {
			isRed = isRed + 1;
			if (isRed > 5) {
				hitFlash.color = new Color (1f, 1f, 1f, 1f);
				isRed = 0;
			}
		}
	}

	public void TakeDamage (int damage)
	{
		hitFlash.color = new Color(0.5f, 0.5f, 0.5f, 1f);
		isRed = 1;
		health -= damage;
		Debug.Log (health);
		audioData.Play (0);
		if (health <= 0) {
			Die ();
		}
	}

	void Die ()
	{
		isDead = true;
		transform.Rotate (new Vector3 (0, 0, -90));

	}

	/*--------------Experimental stuff after this line-----------------*/



}
