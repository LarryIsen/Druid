﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Experiment : MonoBehaviour {

	// Use this for initialization
	void Start () {

	}

	void OnGUI()
		{
		if (Druid.ronian.health > 0) {
			GUILayout.Label (Druid.ronian.health.ToString ());
			//GUILayout.BeginArea(new Rect(10, 10, 110, 100), Druid.ronian.health.ToString ());
		}
		if (Druid.ronian.health <= 0) {
			//GUILayout.BeginArea(new Rect(10, 10, 110, 100), "YOU WIN THE FIGHT!");
			GUILayout.Label ("YOU WIN THE FIGHT!");
		}
		}

	// Update is called once per frame
	void Update () {

		if (Input.GetKey (KeyCode.P)) {
			Time.timeScale = 0;
			Debug.Log ("Stop!");
		} else {
			Time.timeScale = 1;
			Debug.Log ("Go!");
		}

		// This is a fun "pause" routine, but not useful.
		// It freezes motion, but doesn't allows commands to be entered while 
		// things are frozen, and will generate (and animate!) projectiles as normal.


	}
}
