﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dragon : MonoBehaviour {

	public int health = 1000;
	public AudioSource audioData;
	public SpriteRenderer hitFlash;
	public Rigidbody2D rigidBody;
	public float jumpDir;
	public bool isJump;
	public int isRed;
	public bool isDead;
	public float hangtime;
	public Sprite[] sprites;

	static public Dragon dragon;

	// Use this for initialization
	void Start () {
		dragon = this;
		hitFlash = GetComponent<SpriteRenderer> ();
		audioData = GetComponent<AudioSource>();
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
