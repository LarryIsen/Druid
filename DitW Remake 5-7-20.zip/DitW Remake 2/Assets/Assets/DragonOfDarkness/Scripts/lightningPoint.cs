﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class lightningPoint : MonoBehaviour {

	public float speed;
	public Rigidbody2D rb;
	public int damage;
	public SpriteRenderer colorPicker;


	//Use this for initialization
	void Start () {
		speed = 20f;
		rb.velocity = transform.right * speed;
	}

	void Update () {
		//transform.Rotate (new Vector3 (0, 0, -speed));
		//ColorHSV(float hueMin, float hueMax, float saturationMin, float saturationMax, float valueMin, float valueMax);
		if (Time.timeScale != 0) {
			colorPicker = GetComponent<SpriteRenderer> ();
			float red = Random.value;
			float green = Random.value;
			float blue = Random.value;
			colorPicker.color = new Color (red, green, blue, 1f);
		}
	}

	void OnTriggerEnter2D (Collider2D hitInfo)
	{
		Druid druid = hitInfo.GetComponent<Druid> ();
		if (druid != null) {
			damage = 100;
			druid.TakeDamage (damage);
		
		}

		Destroy(gameObject);
		Shooting.isShooting = false;

	}

}