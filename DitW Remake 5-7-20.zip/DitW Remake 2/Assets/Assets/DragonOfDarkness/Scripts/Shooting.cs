﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shooting : MonoBehaviour {

	public Transform firePoint;
	public GameObject spinnyStar;
	public Transform lightningPoint;
	public GameObject zappyZap;
	public int counter = 0;
	static public bool isShooting = false;
	public Sprite [] sprites;
	public SpriteRenderer colorPicker;




	// Update is called once per frame
	void Update () {

		if (Time.timeScale != 0) {

			if (Input.GetKey (KeyCode.F)) {
				counter = counter + 1;
				if (counter >= 40) {
					if (sprites != null) {
						this.GetComponent<SpriteRenderer> ().sprite = sprites [2];
					}
				}
			}
			if ((Input.GetKeyUp (KeyCode.F)) && (counter > 0)) {
				//Debug.Log (counter);
				if (counter >= 40) {
					counter = 0;
					LightningShoot ();
				} else {
					counter = 0;
					Shoot ();
				}
			}
		}
	}

	void Shoot () {
		Instantiate (spinnyStar, firePoint.position, firePoint.rotation);
		isShooting = true;
		//if (sprites != null) {
		//	this.GetComponent<SpriteRenderer> ().sprite = sprites [0];
		//}
	}

	void LightningShoot () {
		//colorPicker.color = new Color (1f, 1f, 1f, 1f);
		Instantiate (zappyZap, lightningPoint.position, lightningPoint.rotation);
		isShooting = true;
		if (sprites != null) {
			this.GetComponent<SpriteRenderer> ().sprite = sprites [0];
		}
	}
}
