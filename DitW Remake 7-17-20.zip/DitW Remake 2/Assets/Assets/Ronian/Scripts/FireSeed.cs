﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FireSeed : MonoBehaviour {

	public float speed;
	public Rigidbody2D rb;
	public int damage;

	// Use this for initialization
	void Start () {

		speed = 25f;
		rb.velocity = transform.right * speed;

	}
	
	// Update is called once per frame
	void Update () {
		
	}

	void OnTriggerEnter2D (Collider2D hitInfo)
	{
		Dragon dragon = hitInfo.GetComponent<Dragon> ();
		if (dragon != null) {
			//Color newColor = new Color(0.3f, 0.3f, 0.3f, 1f);
			//CameraScript.HitFlash (newColor);
			damage = 10;
			dragon.TakeDamage (damage);
		}
		Destroy(gameObject);
		DruidShooting.isShooting = 0;
	}
}