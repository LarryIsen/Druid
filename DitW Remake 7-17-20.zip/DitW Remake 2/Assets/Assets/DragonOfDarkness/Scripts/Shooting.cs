﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Shooting : MonoBehaviour {

	public Transform firePoint;
	public GameObject spinnyStar;
	//public Transform lightningPoint;
	public GameObject zappyZap;
	public int counter = 0;
	static public int isShooting = 0;
	public Sprite [] sprites;
	public SpriteRenderer colorPicker;

	public GameObject zapMark;
	public GameObject fireMark;

	//public GameObject skyLightning; //This is not going to call that, but I'll leave this in anyway for now
	//public GameObject wallPiece;

	static public bool hitDragon = false;




	// Update is called once per frame
	void Update () {

		if (Time.timeScale != 0) {

			if (Input.GetKey (KeyCode.F)) {
				counter = counter + 1;
				if (counter >= 40) {
					if (sprites != null) {
						this.GetComponent<SpriteRenderer> ().sprite = sprites [2];
					}
				}
			} //if Getkey (F)

			if ((Input.GetKeyUp (KeyCode.F)) && (counter > 0)) {
				//Debug.Log (counter);
				if (counter >= 40) {
					counter = 0;
					LightningShoot ();
				} else {
					counter = 0;
					if (isShooting < 3) {
						Shoot ();
					}
				}
			} //if GetKeyUp (f)

				int shooting = Random.Range (1, 1001);
			if ((DruidShooting.isShooting == 0) && (Time.timeScale > 0) && (Druid.isDead == false)) {
				if (shooting < 10) {
					CallLightning ();
					DruidShooting.isShooting = 2;
				} else if ((shooting >= 10) && (shooting < 20)) {
					FireWall ();
					DruidShooting.isShooting = 2;
				}
			}
					
				



		} // if Time.timeScale != 0

		if (Input.GetKeyDown (KeyCode.Y)) {
			CallLightning();
		} //if (Input.GetKeyDown (KeyCode.Y))


		if (Input.GetKeyDown (KeyCode.T)) {
			FireWall();
		} //if (Input.GetKeyDown (KeyCode.T))

	}

	//--------------------------------------------

	void Shoot () {

		Vector3 loc = firePoint.position;
		loc.x = loc.x + 0.5f; //temp - 1;

		//Instantiate (spinnyStar, firePoint.position, firePoint.rotation);
		Instantiate (spinnyStar, loc, firePoint.rotation);
		isShooting += 1;
		//if (sprites != null) {
		//	this.GetComponent<SpriteRenderer> ().sprite = sprites [0];
		//}
	}

	//--------------------------------------------

	void LightningShoot () {
		//colorPicker.color = new Color (1f, 1f, 1f, 1f);
		//Instantiate (zappyZap, lightningPoint.position, lightningPoint.rotation);

		Vector3 loc = firePoint.position;
		loc.x = loc.x + 0.5f; //temp - 1;

		//Instantiate (zappyZap, firePoint.position, firePoint.rotation);
		Instantiate (zappyZap, loc, firePoint.rotation);
		isShooting += 2;
		if (sprites != null) {
			this.GetComponent<SpriteRenderer> ().sprite = sprites [0];
		}
	}

	//--------------------------------------------

	void CallLightning(){

		//Time.timeScale = 0;

		//for (int i = 0; i < 10; i++)
		//{
			//Instantiate(skyLightning, new Vector3(i * 2.0F, 0, 0), Quaternion.identity);
			//Vector3 temp = (firePoint.position.x, firePoint.position.y, firePoint.position.z);
			// = firePoint.position.x + (float)i;
			//Instantiate(skyLightning, firePoint.position, Quaternion.identity);
		//}

		//Time.timeScale = 1;
		//Instantiate (seedDot, fireSeed.position, fireSeed.rotation);

		/*
		 Okay, okay, forget all that.  All this needs to do is just instantiate the object
		 on the floor below the Dragon's feet, and nothing else. The object itself should 
		 have a script that handles the countdown and instantiate the lightning bolt(s) attack.
		*/

		Vector3 loc = firePoint.position;
		//float temp = loc.y;
		loc.y = -1.375f; //temp - 1;
		//print (temp-1);
		Instantiate (zapMark, loc, Quaternion.identity); //firePoint.rotation);

	}

	//--------------------------------------------

	void FireWall(){

		/*
		 Same as above, but it creates a different object.  The main question is - should both be
		 active at the same time?  I'm leaning towards "no", but the difference is only one line
		 of code, so I can put that in later.
		*/

		/*
		The above now uses the Druid's "isShooting" boolean, so the Druid will only have one attack
		on screen at a time.
		*/

		Vector3 loc = firePoint.position;
		//float temp = loc.y;
		loc.y = -1.375f; //temp - 1;
		//print (temp-1);
		Instantiate (fireMark, loc, Quaternion.identity); //firePoint.rotation);

	}
}