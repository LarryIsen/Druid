﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CallCallLightning : MonoBehaviour {

	public int timer;
	public Transform markPoint;
	public GameObject Lightning;

	static public int bolts;

	// Use this for initialization
	void Start () {
		if (Druid.ronian.sprites != null) {
			Druid.ronian.GetComponent<SpriteRenderer> ().sprite = Druid.ronian.sprites [2];
		}
		timer = 50;
	} //Start()
	
	// Update is called once per frame
	void Update () {
		timer--;
		if (timer <= 0) {
			//Time.timeScale = 0;
			if (Druid.ronian.sprites != null) {
				Druid.ronian.GetComponent<SpriteRenderer> ().sprite = Druid.ronian.sprites [3];
			}
			bolts = 0;
			callLightning ();
			Destroy (gameObject);
			//Time.timeScale = 1;
			//DruidShooting.isShooting = false;
			if (Druid.ronian.sprites != null) {
				Druid.ronian.GetComponent<SpriteRenderer> ().sprite = Druid.ronian.sprites [0];
			}
		}
	} //Update()

	void callLightning()
	{
		Vector3 loc = markPoint.position;
		//Instantiate (zappyZap, markPoint.position, markPoint.rotation);
		loc.y = loc.y + 6.2f;
		loc.x = loc.x + 6.2f;
		//print (temp-1);
		Instantiate (Lightning, loc, Quaternion.identity);

		/*
			This generates the first instantce of the callLightning object.
			Each instance of the callLightning object will check to see whether it's hit
			either the Dragon or the ground, at which point it does damage and destroys itself.
			If it hits neither, it generates another instance of the object.
			It executes a destroy(gameObject) after the check.
			(Probably put a pause in there somewhere)
		*/
	} //callLightning()

}
