﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Dragon : MonoBehaviour {

	public int health = 1000;
	public AudioSource audioData;
	public SpriteRenderer hitFlash;
	public Rigidbody2D rigidBody;
	public float jumpDir;
	public bool isJump;
	public int isRed;
	static public bool isDead = false;
	public float hangtime;
	public Sprite[] sprites;

	static public Dragon dragon;

	// Use this for initialization
	void Start () {
		dragon = this;
		hitFlash = GetComponent<SpriteRenderer> ();
		audioData = GetComponent<AudioSource>();
	}
	
	// Update is called once per frame
	void Update () {
		if (isRed > 0) {
			isRed = isRed + 1;
			if (isRed > 5) {
				hitFlash.color = new Color (1f, 1f, 1f, 1f);
				isRed = 0;
			}
		}
	}

	public void TakeDamage (int damage)
	{
		hitFlash.color = new Color(1f, 0.5f, 0.5f, 1f);
		isRed = 1;
		health -= damage;
		//audioData.Play (0);
		//if (health <= 0) {
		//	DragonDie ();
		//}
	}

	void DragonDie ()
	{
		isDead = true;
		transform.Rotate (new Vector3 (0, 0, -90));

	}
}
