﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Experiment : MonoBehaviour {


	//public CanvasGroup myCG;
	private bool flash = false;

	public string gameSceneName="Victory!";

	// Use this for initialization
	void Start () {

	}

	void OnGUI() {
		/*if (Druid.ronian.health > 0) {
			GUILayout.Label (Druid.ronian.health.ToString ());
			//GUILayout.BeginArea(new Rect(10, 10, 110, 100), Druid.ronian.health.ToString ());
		}
		if (Druid.ronian.health <= 0) {
			//GUILayout.BeginArea(new Rect(10, 10, 110, 100), "YOU WIN THE FIGHT!");
			GUILayout.Label ("YOU WIN THE FIGHT!");
		}*/

	} //OnGUI()


	// Update is called once per frame
	void Update () {

		if (Input.GetKey (KeyCode.P)) {
			// This is a fun "pause" routine, but not useful.
			// It freezes motion, but allows commands to be entered while 
			// things are frozen, and will generate (and animate!) projectiles as normal.
			// Edit: Things in Update() functions keep moving as normal, but can still be
			// paused by multiplying things by or checking the value of Time.timeScale.
			Time.timeScale = 0;
		} else {
			Time.timeScale = 1;
		} //If "P" then freeze

		if (Input.GetKey (KeyCode.O)) {
			// Attempting to make a second pause routine that will
			// freeze everything for five seconds.  So far, not working.
			Debug.Log ("Freeze!");
			Freezie ();
			Debug.Log ("Unfreeze!");
		} //If "O" then freeze for five seconds?
			

		if (Input.GetKey (KeyCode.Q)) {
			SceneManager.LoadScene(gameSceneName);
		}



		//if ((Input.GetKey (KeyCode.I)) && (!flash)) {
		//	myCG.alpha = 1;
		//	flash = true;
		//} //If "I" then start screen flash

		//if (flash){
		//	myCG.alpha = myCG.alpha - Time.deltaTime;
		//	if (myCG.alpha <= 0) {
		//		myCG.alpha = 0;
		//		flash = false;
		//	}
		//} //screen flash, part 2 
		// Flashing screen routine is in Camera script.
		 
	} //Update

	IEnumerator Freezie	()
	{
		print(Time.time);
		Debug.Log (Time.time);
		yield return new WaitForSecondsRealtime(5);
		yield return new WaitForSeconds(5);
		print(Time.time);
		Debug.Log (Time.time);
	}
		

}
