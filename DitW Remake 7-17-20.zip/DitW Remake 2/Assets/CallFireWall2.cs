﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CallFireWall2 : MonoBehaviour {

	//because CallFireWall got itself disconnected from the reference object

	public int timer;
	public Transform wallPoint;
	public GameObject Firewall;

	static public int bolts;

	// Use this for initialization
	void Start () {
		if (Druid.ronian.sprites != null) {
			Druid.ronian.GetComponent<SpriteRenderer> ().sprite = Druid.ronian.sprites [2];
		}
		timer = 50;
	} //Start()

	// Update is called once per frame
	void Update () {
		timer--;
		//print (timer);
		if (timer <= 0) {
			if (Druid.ronian.sprites != null) {
				Druid.ronian.GetComponent<SpriteRenderer> ().sprite = Druid.ronian.sprites [3];
			}
			bolts = 0;
			//callLightning ();
			fireWall();
			Destroy (gameObject);
			//DruidShooting.isShooting = false;
			if (Druid.ronian.sprites != null) {
				Druid.ronian.GetComponent<SpriteRenderer> ().sprite = Druid.ronian.sprites [0];
			}
		}
	} //Update()

	/*void callLightning()
	{
		Vector3 loc = markPoint.position;
		//Instantiate (zappyZap, markPoint.position, markPoint.rotation);
		loc.y = loc.y + 6.2f;
		loc.x = loc.x + 6.2f;
		//print (temp-1);
		Instantiate (Lightning, loc, Quaternion.identity);
		
	} //callLightning() */

	void fireWall()
	{
		//Time.timeScale = 0;
		Vector3 loc = wallPoint.position;
		loc.y = loc.y + 1.1f;
		Instantiate (Firewall, loc, Quaternion.identity);
		/*int i = 0;
		while (i < 10000) {
			i++;
		}*/



		//Time.timeScale = 1;
	}
}
